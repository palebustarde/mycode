﻿using ApplicationLibrary.Interfaces;
using ApplicationLibrary.Models;
using System.Threading.Tasks;

namespace ApplicationLibrary.Behaviors
{
	public static class IncomeCalculator
	{
		public abstract class BaseIncomeCalculator : ICalculator
		{
			public abstract Task<decimal> Calculate(IncomeModel model);
		}

		public class IncomeAfterTax : BaseIncomeCalculator
		{
			public override async Task<decimal> Calculate(IncomeModel model)
			{
				decimal taxAmount = (model.GrossIncome * (decimal)(model.TaxRate/100)) + model.MinimumTaxAmount;
				decimal result = model.GrossIncome - taxAmount;
				return await Task.FromResult(result);
			}
		}

		public class PreTaxFromTakeHome : BaseIncomeCalculator
		{
			public override async Task<decimal> Calculate(IncomeModel model)
			{
				decimal taxAmount = (model.GrossIncome * (decimal)(model.TaxRate / 100)) + model.MinimumTaxAmount;
				return await Task.FromResult(taxAmount);
			}
		}
	}
}
