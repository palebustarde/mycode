﻿using ApplicationLibrary.Interfaces;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ApplicationLibrary.Behaviors
{
	public static class WordProcessor
	{
		public abstract class BaseWordProcessor : IWordProcessor
		{
			public abstract Task<List<string>> Process(List<string> words);
		}

		public class ReverseWords : BaseWordProcessor
		{
			public override async Task<List<string>> Process(List<string> words)
			{
				List<string> reversedWords = words;
				reversedWords.Reverse();
				return await Task.FromResult(reversedWords);
			}
		}

		public class SortWords : BaseWordProcessor
		{
			public override async Task<List<string>> Process(List<string> words)
			{
				List<string> sortedWords = words;
				sortedWords.Sort();
				return await Task.FromResult(sortedWords);
			}
		}
	}
}
