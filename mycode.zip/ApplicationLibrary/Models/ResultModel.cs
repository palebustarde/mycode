﻿namespace ApplicationLibrary.Models
{
	public class ResultModel<T>
	{
		public T Result { get; set; }
		public string Message { get; set; }
	}
}
