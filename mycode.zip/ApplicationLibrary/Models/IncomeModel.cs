﻿namespace ApplicationLibrary.Models
{
	public class IncomeModel
	{
		public float TaxRate { get; set; }
		public decimal GrossIncome { get; set; }
		public decimal MinimumTaxAmount { get; set; }
	}
}
