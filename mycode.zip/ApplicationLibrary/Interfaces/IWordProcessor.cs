﻿using System.Collections.Generic;
using System.Threading.Tasks;

namespace ApplicationLibrary.Interfaces
{
	public interface IWordProcessor
	{
		public Task<List<string>> Process(List<string> words);
	}
}
