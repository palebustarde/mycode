﻿using ApplicationLibrary.Models;
using System.Threading.Tasks;

namespace ApplicationLibrary.Interfaces
{
	public interface ICalculator
	{
		public Task<decimal> Calculate(IncomeModel income);
	}
}
