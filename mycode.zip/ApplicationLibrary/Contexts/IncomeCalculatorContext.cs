﻿using ApplicationLibrary.Interfaces;
using ApplicationLibrary.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ApplicationLibrary.Contexts
{
	public class IncomeCalculatorContext
	{
		private ICalculator _context;

		public IncomeCalculatorContext(ICalculator context)
		{
			_context = context;
		}

		public void SetWordProcessor(ICalculator context)
		{
			_context = context;
		}

		public async Task<decimal> Calculate(IncomeModel model)
		{
			if (IsPameterValid(model))
			{
				decimal result = await _context.Calculate(model);
				return result;
			}
			return 0;
		}

		private bool IsPameterValid(IncomeModel model)
		{
			if (model is not null || model.GrossIncome>0 || model.TaxRate>0)
			{
				return true;
			}
			else
			{
				return false;
			}
		}
	}
}
