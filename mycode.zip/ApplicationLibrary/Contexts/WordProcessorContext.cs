﻿using ApplicationLibrary.Interfaces;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ApplicationLibrary.Contexts
{
	public class WordProcessorContext
	{
		private IWordProcessor _context;

		public WordProcessorContext(IWordProcessor context)
		{
			_context = context;
		}

		public void SetWordProcessor(IWordProcessor context)
		{
			_context = context;
		}

		public async Task<List<string>> Process(List<string> words)
		{
			if (IsPameterValid(words))
			{
				List<string> result = await _context.Process(words);
				return result;
			}
			return null;
		}

		private bool IsPameterValid(List<string> words)
		{
			if (words is null)
			{
				return false;
			}
			else
			{
				return true;
			}
		}
	}
}
