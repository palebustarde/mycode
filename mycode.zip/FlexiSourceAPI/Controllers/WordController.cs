﻿using ApplicationLibrary.Behaviors;
using ApplicationLibrary.Contexts;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FlexiSourceAPI.Controllers
{
	[Route("api/[controller]")]
	[ApiController]
	public class WordController : ControllerBase
	{
		WordProcessorContext _context;

		[HttpGet("reverse-words")]
		public async Task<ActionResult<List<string>>> GetReversedWords([FromQuery] string commaDelimitedWords)
		{
			List<string> result;
			List<string> words = commaDelimitedWords.Split(",").ToList();

			try
			{
				_context = new(new WordProcessor.ReverseWords());
				result = await _context.Process(words);
			}
			catch (Exception)
			{
				return null;
			}

			return words;
		}

		[HttpGet("sort-words")]
		public async Task<ActionResult<List<string>>> GetSortedWords([FromQuery] string commaDelimitedWords)
		{
			List<string> result;
			List<string> words = commaDelimitedWords.Split(",").ToList();

			try
			{
				_context = new(new WordProcessor.SortWords());
				result = await _context.Process(words);
			}
			catch (Exception)
			{
				return null;
			}

			return words;
		}
	}
}
