﻿using ApplicationLibrary.Behaviors;
using ApplicationLibrary.Contexts;
using ApplicationLibrary.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Threading.Tasks;

namespace FlexiSourceAPI.Controllers
{
	[Route("api/[controller]")]
	[ApiController]
	public class IncomeController : ControllerBase
	{
		IncomeCalculatorContext _context;

		[HttpGet("calculate-after-tax-income")]
		public async Task<ActionResult<decimal>> GetIncomeAfterTax([FromQuery] IncomeModel model)
		{
			decimal result = 0;
			try
			{
				_context = new(new IncomeCalculator.IncomeAfterTax());
				result = await _context.Calculate(model);
			}
			catch (Exception)
			{
				return 0;
			}

			return Ok(result);
		}

		[HttpGet("calculate-pre-tax-income-from-take-home")]
		public async Task<ActionResult<decimal>> GetPreTaxFromTakeHome([FromQuery] IncomeModel model)
		{
			decimal result = 0;
			try
			{
				_context = new(new IncomeCalculator.PreTaxFromTakeHome());
				result = await _context.Calculate(model);
			}
			catch (Exception)
			{
				return 0;
			}

			return Ok(result);
		}
	}
}
